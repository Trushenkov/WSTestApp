-- MySQL dump 10.13  Distrib 8.0.14, for Win64 (x86_64)
--
-- Host: localhost    Database: public
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `склад материалов`
--

DROP TABLE IF EXISTS `склад материалов`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `склад материалов` (
  `﻿Идентификатор листа` int(11) NOT NULL,
  `Артикул материала` varchar(255) NOT NULL,
  `Длина, мм` int(11) NOT NULL,
  `Ширина, мм` int(11) NOT NULL,
  `Количество листов` int(11) NOT NULL,
  PRIMARY KEY (`﻿Идентификатор листа`,`Артикул материала`),
  KEY `артикул материала3_idx` (`Артикул материала`),
  CONSTRAINT `артикул материала3` FOREIGN KEY (`Артикул материала`) REFERENCES `материал` (`Артикул`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `склад материалов`
--

LOCK TABLES `склад материалов` WRITE;
/*!40000 ALTER TABLE `склад материалов` DISABLE KEYS */;
INSERT INTO `склад материалов` VALUES (125125,'7777DVP',2140,1220,50),(125126,'7778DVP',2620,1220,40),(125127,'7779DVP',2440,1830,100),(125128,'8881DSP',1750,3500,80),(125129,'8882DSP',1750,2750,50),(125130,'8883DSP',1830,2750,100),(125131,'9991ФК',1525,1525,100),(125132,'9992ФК',1220,760,15),(125133,'55551РЛ',3050,1300,10),(125134,'55552РЛ',3050,1300,18),(125135,'55553РЛ',4200,2440,200),(125136,'55554РЛ',2800,1300,100);
/*!40000 ALTER TABLE `склад материалов` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-26 11:53:23
