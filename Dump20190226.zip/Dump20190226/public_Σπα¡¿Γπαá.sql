-- MySQL dump 10.13  Distrib 8.0.14, for Win64 (x86_64)
--
-- Host: localhost    Database: public
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `фурнитура`
--

DROP TABLE IF EXISTS `фурнитура`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `фурнитура` (
  `Артикул фурнитуры` varchar(255) NOT NULL,
  `Наименование` varchar(255) NOT NULL,
  `Тип` varchar(255) NOT NULL,
  `Длина, мм` varchar(255) DEFAULT NULL,
  `Ширина, мм` varchar(255) DEFAULT NULL,
  `Вес` varchar(255) DEFAULT NULL,
  `Изображение` varchar(255) DEFAULT NULL,
  `Цена` int(11) NOT NULL,
  PRIMARY KEY (`Артикул фурнитуры`),
  KEY `артикул фурнитуры` (`Артикул фурнитуры`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `фурнитура`
--

LOCK TABLES `фурнитура` WRITE;
/*!40000 ALTER TABLE `фурнитура` DISABLE KEYS */;
INSERT INTO `фурнитура` VALUES ('34АФ','Петля накладная','FGV','','','','',135),('35ВФ','Петля накладная','TIOMOS','','','','',350),('36СФ','Петля накладная','A04','','','','',99),('37ДФ','Петля мебельная','RD-14E','','','','',150),('38ДФ','Стяжка мебельная','FTS ','','','','',1),('39ДФ','Ручка-скоба','XR','160','','','',500),('40ДФ','Ручка','Me','96','','','',180),('41ДФ','Втулка','PL','','','','',4),('42ДФ','Евро-винт М7*70','EV','','','','',10),('43ДФ','Евро-винт М4*35','EV','','','','',5),('44ДФ','Монтажный уголок на 4 шурупа М6*10','VS','','','','',15),('46ДФ','Монтажный уголок на 4 шурупа','МU','20','20','','',20),('47ДФ','Полкодержатель стяжка коричневый','D20','','','','',79),('48ДФ','Полкодержатель стяжка белый','D40','','','','',49);
/*!40000 ALTER TABLE `фурнитура` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-26 11:53:16
