-- MySQL dump 10.13  Distrib 8.0.14, for Win64 (x86_64)
--
-- Host: localhost    Database: public
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `материал`
--

DROP TABLE IF EXISTS `материал`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `материал` (
  `Артикул` varchar(255) NOT NULL,
  `Наименование` varchar(255) NOT NULL,
  `Марка` varchar(255) NOT NULL,
  `Цвет` varchar(255) DEFAULT NULL,
  `Длина, мм` int(11) NOT NULL,
  `Ширина, мм` int(11) NOT NULL,
  `Цена` int(11) NOT NULL,
  PRIMARY KEY (`Артикул`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `материал`
--

LOCK TABLES `материал` WRITE;
/*!40000 ALTER TABLE `материал` DISABLE KEYS */;
INSERT INTO `материал` VALUES ('55551РЛ','Пластик-1.2','LM601','Белый',3050,1300,1400),('55552РЛ','Пластик-1.2','LM602','Голубой',3050,1300,1400),('55553РЛ','Пластик HPL','D4103BS','Декоративный',4200,2440,3500),('55554РЛ','Пластик HPL','DВ1104','Декоративный',2800,1300,2800),('7777DVP','ДВП-2.5','ТСН-20','Шампонь',2140,1220,210),('7778DVP','ДВП-3.5','ТСН-30','Темно-коричневый',2620,1220,400),('7779DVP','ДВП-5','ТСН-40','Светло-коричневый',2440,1830,450),('8881DSP','ДСП','ПАI','Светло-коричневый',1750,3500,1050),('8882DSP','ДСП','ПБI','Светло-коричневый',1750,2750,989),('8883DSP','ДСП','ЕI','Темно-коричневый',1830,2750,750),('9991ФК','Фанера нешлифованная-18','ФК1','Светлый',1525,1525,699),('9992ФК','Фанера шлифованная-10','ФК2','Светлый',1220,760,849);
/*!40000 ALTER TABLE `материал` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-26 11:53:18
