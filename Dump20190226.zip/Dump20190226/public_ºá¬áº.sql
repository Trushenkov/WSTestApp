-- MySQL dump 10.13  Distrib 8.0.14, for Win64 (x86_64)
--
-- Host: localhost    Database: public
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `заказ`
--

DROP TABLE IF EXISTS `заказ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `заказ` (
  `Номер заказа` int(11) NOT NULL AUTO_INCREMENT,
  `Дата` date NOT NULL,
  `Этап выполнения` varchar(255) NOT NULL,
  `Заказчик` varchar(255) NOT NULL,
  `Менеджер` varchar(255) NOT NULL,
  `Стоимость` int(11) NOT NULL,
  PRIMARY KEY (`Номер заказа`,`Дата`),
  KEY `заказчик_idx` (`Заказчик`),
  KEY `менеджер` (`Менеджер`),
  CONSTRAINT `заказчик` FOREIGN KEY (`Заказчик`) REFERENCES `пользователь` (`Наименование`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `менеджер` FOREIGN KEY (`Менеджер`) REFERENCES `пользователь` (`Наименование`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `заказ`
--

LOCK TABLES `заказ` WRITE;
/*!40000 ALTER TABLE `заказ` DISABLE KEYS */;
INSERT INTO `заказ` VALUES (100,'2010-01-20','Производство','Иванов','Петров',10000),(101,'2012-01-20','Ожидает','Юткин','Петров',10000),(102,'2012-01-20','Ожидает','Колычев','Сидоров',28500),(103,'2020-01-20','Новый','Лыков','Сидоров',10700),(104,'2019-10-01','Новый','Иванов','Сидоров',1000),(105,'2019-02-24','Новый','Иванов','Сидоров',666),(106,'2019-02-24','Новый','Иванов','Сидоров',15129),(107,'2019-02-24','Новый','Иванов','Сидоров',444),(108,'2019-02-24','Новый','Иванов','Сидоров',2676),(109,'2019-02-24','Новый','Петров','Сидоров',861),(110,'2019-02-25','Новый','Петров','Сидоров',444),(111,'2019-02-25','Новый','Петров','Сидоров',15129),(112,'2019-02-25','Новый','Петров','Сидоров',15129),(113,'2019-02-25','Новый','Петров','Сидоров',27306);
/*!40000 ALTER TABLE `заказ` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-26 11:53:22
