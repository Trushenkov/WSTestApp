-- MySQL dump 10.13  Distrib 8.0.14, for Win64 (x86_64)
--
-- Host: localhost    Database: public
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `склад фурнитуры`
--

DROP TABLE IF EXISTS `склад фурнитуры`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `склад фурнитуры` (
  `﻿Партия` int(11) NOT NULL,
  `Артикул фурнитуры` varchar(255) NOT NULL,
  `Количество` int(11) NOT NULL,
  PRIMARY KEY (`﻿Партия`,`Артикул фурнитуры`),
  KEY `артикул фурнитуры_idx` (`Артикул фурнитуры`),
  CONSTRAINT `артикул фурнитуры` FOREIGN KEY (`Артикул фурнитуры`) REFERENCES `фурнитура` (`Артикул фурнитуры`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `склад фурнитуры`
--

LOCK TABLES `склад фурнитуры` WRITE;
/*!40000 ALTER TABLE `склад фурнитуры` DISABLE KEYS */;
INSERT INTO `склад фурнитуры` VALUES (20190121,'34АФ',500),(20190122,'35ВФ',600),(20190123,'36СФ',500),(20190212,'37ДФ',500),(20190213,'38ДФ',300),(20190214,'39ДФ',200),(20190215,'40ДФ',300),(20190216,'41ДФ',1000),(20190217,'42ДФ',1000),(20190218,'43ДФ',1000),(20190219,'44ДФ',1000),(20190221,'46ДФ',1000),(20190222,'47ДФ',1000),(20190223,'48ДФ',1500);
/*!40000 ALTER TABLE `склад фурнитуры` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-26 11:53:30
