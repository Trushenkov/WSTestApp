-- MySQL dump 10.13  Distrib 8.0.14, for Win64 (x86_64)
--
-- Host: localhost    Database: public
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `поступаемые материалы`
--

DROP TABLE IF EXISTS `поступаемые материалы`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `поступаемые материалы` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Поставщик` varchar(255) NOT NULL,
  `Материал` varchar(45) NOT NULL,
  `Количество` int(11) NOT NULL,
  `Закупочная стоимость` int(11) NOT NULL,
  `Сумма` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `поступаемые материалы`
--

LOCK TABLES `поступаемые материалы` WRITE;
/*!40000 ALTER TABLE `поступаемые материалы` DISABLE KEYS */;
INSERT INTO `поступаемые материалы` VALUES (1,'Поставщик 3','wqw',12,33,396),(2,'Поставщик 3','123',33,33333,1099989),(3,'Поставщик 3','123',33,33333,1099989),(4,'Поставщик 4','вфывфыв',22,1,22),(5,'Поставщик 3','123',33,33333,1099989),(6,'Поставщик 4','вфывфыв',22,1,22),(7,'Поставщик 4','вфывфыв',22,1,22),(8,'Поставщик 3','asd',213,23,4899),(9,'Поставщик 3','asd',213,23,4899),(10,'Поставщик 3','asd',213,23,4899),(11,'Поставщик 3','qwe',123,33,4059),(12,'Поставщик 4','aaaa',123,33,4059),(13,'Поставщик 4','asdad',4444,33,4059),(14,'Поставщик 2','d',12,22,264),(15,'Поставщик 4','aaaaaaaaaaaaaaa',51231,43,2202933),(16,'Поставщик 3','asdasd',13342342,1312,325283520),(17,'Поставщик 3','asdasd',13342342,1312,325283520),(18,'Поставщик 2','ddddddd',2,21,42),(19,'Поставщик 1','123',123,32,3936),(20,'Поставщик 1','123',123,32,3936),(21,'Поставщик 3','asdasd',23,123,2829),(22,'Поставщик 2','123',123,213,26199),(23,'Поставщик 2','123',123,213,26199),(24,'Поставщик 1','123',12123,22,266706),(25,'Поставщик 1','123',12123,22,266706),(26,'Поставщик 1','213',123,123,15129),(27,'Поставщик 2','Пластик HPL',12,12,144),(28,'Поставщик 2','ДВП-2.5',333,12,3996),(29,'Поставщик 2','ДВП-3.5',333,12,3996),(30,'Поставщик 2','ДВП-3.5',333,12,3996),(31,'Поставщик 2','Фанера нешлифованная-18',2,12,24),(32,'Поставщик 1','Пластик HPL',2,12,24),(33,'Поставщик 4','ДСП',2,12,24),(34,'Поставщик 4','ДСП',2,12,24);
/*!40000 ALTER TABLE `поступаемые материалы` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-26 11:53:32
