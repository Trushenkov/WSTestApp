-- MySQL dump 10.13  Distrib 8.0.14, for Win64 (x86_64)
--
-- Host: localhost    Database: public
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `фурнитура изделия`
--

DROP TABLE IF EXISTS `фурнитура изделия`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `фурнитура изделия` (
  `Артикул фурнитуры` varchar(255) NOT NULL,
  `Артикул изделия` int(11) NOT NULL,
  `Размещение` varchar(255) DEFAULT NULL,
  `Размер` varchar(255) DEFAULT NULL,
  `Поворот` varchar(255) DEFAULT NULL,
  `Количество` int(11) NOT NULL,
  PRIMARY KEY (`Артикул фурнитуры`,`Артикул изделия`),
  KEY `артикул изделия5_idx` (`Артикул изделия`),
  CONSTRAINT `артикул изделия5` FOREIGN KEY (`Артикул изделия`) REFERENCES `изделие` (`Артикул`),
  CONSTRAINT `артикул фурнитуры4` FOREIGN KEY (`Артикул фурнитуры`) REFERENCES `фурнитура` (`Артикул фурнитуры`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `фурнитура изделия`
--

LOCK TABLES `фурнитура изделия` WRITE;
/*!40000 ALTER TABLE `фурнитура изделия` DISABLE KEYS */;
INSERT INTO `фурнитура изделия` VALUES ('35ВФ',111058,'','','',4),('37ДФ',222033,'В,Н','','',2),('38ДФ',111058,'','','',4),('39ДФ',222033,'В','','',1),('40ДФ',111058,'','','',2),('41ДФ',111058,'','','',16),('41ДФ',111111,'','','',16),('41ДФ',222033,'','','',16),('43ДФ',111058,'','','',16),('43ДФ',111111,'','','',16),('43ДФ',222033,'','','',16),('44ДФ',111058,'','','',16),('44ДФ',111111,'','','',8),('44ДФ',222033,'В,Н','','',16),('47ДФ',111111,'','','',20),('48ДФ',111058,'','','',16),('48ДФ',222033,'','','',12);
/*!40000 ALTER TABLE `фурнитура изделия` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-26 11:53:26
